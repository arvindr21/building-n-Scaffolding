'use strict';
/**
* Created with gruntSampleProject.
* User: arvindr21
* Date: 2014-06-12
* Time: 05:38 AM
* To change this template use Tools | Templates.
*/
define(function() {
    var location = window.location.href;
return {
    method1  : function(){
        alert('Hello World! from '+location);
    }
};
});