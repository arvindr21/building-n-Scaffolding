Install
-------

* Run `npm install`
* Run `gulp <task-name`