'use strict';

var gulp = require('gulp');
var concat = require('gulp-concat');

gulp.task('concat', function() {
  gulp.src('src/**/*.js')
    .pipe(concat('app.js'))
    .pipe(gulp.dest('./dist/js/'));
});

//gulp.task('all', ['jshint','concat','uglify']);	