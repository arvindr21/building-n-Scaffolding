'use strict';

function test(a) {
    if (a) {
        var x = 1;
        x = x * 100;
    }
    return x;
}

test();