'use strict';

/**
* Created with gruntSampleProject.
* User: arvindr21
* Date: 2014-06-12
* Time: 05:56 AM
* To change this template use Tools | Templates.
*/
define(function() {
return {
    anotherFxn : function(){
        console.log('From another function');
    }
};
});